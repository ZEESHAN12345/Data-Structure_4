import java.io.*;
import java.util.*;

/** main Class starts from here **/
class Huff_Enc_Dec {
    
	/* main Function starts from here*/
	public static void main(String[] args){
		
                   /* 
		    * 'inputTextFile'         -->          contains the filename of input text document.
		    * 'outputBinaryFile'      -->       contains the filename of output binary file.
		    * 'outputHuffmanTreeFile' -->  contains the filename of output Huffman Tree.
		    * */
		   Scanner filename = new Scanner(System.in);
	   	   System.out.println("Please enter the file name which contains the text doxument to be encoded:");
	   	   String inputTextFile = filename.nextLine();
	   	   inputTextFile = inputTextFile + ".txt";
	   	   
	   	   Scanner filename1 = new Scanner(System.in);
	   	   System.out.println("Please give the name to the binary file you want to output:");
	   	   String outputBinaryFile = filename1.nextLine();
	   	   outputBinaryFile = outputBinaryFile + ".txt";
	   	   
	   	   Scanner filename2 = new Scanner(System.in);
	  	   System.out.println("Please give the name for ouput Huffman Tree text file");
	  	   String outputHuffmanTreeFile = filename2.nextLine();
	  	   outputHuffmanTreeFile = outputHuffmanTreeFile + ".txt";
		   
	       tokenEncode( HuffmanTree(freq_calc(inputTextFile)), "" );
	       textOutEncodings(outputHuffmanTreeFile, hash_table);

	       try {
	            binaryOutEncoding(inputTextFile, outputBinaryFile);
	            textOutDecodings( decode(outputBinaryFile, HuffmanTree(freq_calc(inputTextFile))) );
	       } catch (IOException error) {
	           error.printStackTrace();
	       }
	      
	   }
	
	
   /*variables for 
    * Hash Table 
    * and 
    * Huffman Tree**/
   private static Map<String, String> hash_table = new LinkedHashMap<String, String>();
   private static node huffman_tree;
   
   /*static String inputTextFile; // filename - input text file
   static String outputBinaryFile; // filename1 - output binary file
   static String outputHuffmanTreeFile; // filename 2 - output String-binary file
   static String outputDecodedFile; // filename 3 - output decode text file*/
    
   /* this Method calculates and stores the 
    * frequency corresponding to each token in
    * in a given input file into a Hash Table */
   public static Map<String, Integer> freq_calc(String inputTextFile){
	   
       Map<String, Integer> freq = new LinkedHashMap<String, Integer>();
       
       try( BufferedReader br = new BufferedReader(new FileReader(inputTextFile)) ) {
    	   String line;
    	   String s = "";
    	    while ((line = br.readLine()) != null) {
    	    	s = s + "\n";
    	        s = s + line;
    	    }
    	   s = s.substring(1);
           
           StringTokenizer tokens = new StringTokenizer(s, "[ =+';().*{}[],!@#$%^&/]", true); 
	        while(tokens.hasMoreTokens()){
	        	String token = tokens.nextToken().toString();
	        	if(freq.containsKey(token))
	                   freq.put(token, freq.get(token) + 1);
				else 
					freq.put(token, 1);
	        }
	        
       } catch (Exception e) {
           System.out.println(e);
           System.exit(0);
       }

       return freq;
}
   
   
   /* this Method creates and return the Huffman tree
    * whose leaves contain the tokens of input file. */
   public static node HuffmanTree(Map<String, Integer> freq) {
	   
	   min_heap MIN_HEAP = new min_heap();
	   
       for(String tok : freq.keySet()) {
           node tree = new node(tok, freq.get(tok), null, null);
           MIN_HEAP.insert(tree);
       }
       MIN_HEAP.minHeap();
       
       while(!MIN_HEAP.isEmpty()) {
    	   
           if(MIN_HEAP.size() > 2) {  
               node n1 = MIN_HEAP.removeMin();
               node n2 = MIN_HEAP.removeMin();
               int frequency = n1.getFreq() + n2.getFreq();
               node huffman_tree = new node("", frequency, n1, n2);
               MIN_HEAP.insert(huffman_tree);
               MIN_HEAP.minHeap();
           }
           
           if(MIN_HEAP.size() == 2) {
        	   node result = MIN_HEAP.removeMin();
        	   MIN_HEAP.insert(result);
               return MIN_HEAP.removeMin();
           }

       }
       return huffman_tree;
   }
   
   
   /* this Method creates and stores the binary 
    * encodings corresponding to each tokens
    * saved in the Huffman Tree into a Hash Table */
   public static void tokenEncode(node n, String s) {

       if(!n.isLeaf(n)) {
           tokenEncode(n.getLeft(), s + "0");
           tokenEncode(n.getRight(), s + "1");
       }
       else
           hash_table.put(n.getElement(), s);
       
       }
   
   
   /* this Method creates the output text file
    * containing the Binary Encodings corresponding
    *  to each token saved in the Huffman Tree */
   public static void textOutEncodings(String outputHuffmanTreeFile, Map<String, String> m) {
	   
	 try {
		 
       ArrayList<String> str = new ArrayList<String>();
       for(String tok : m.keySet()) {
           str.add(tok);
           Collections.sort(str);
       }
       
       String print = "";
       print = print + "Binary Encoding of each token in the Huffman Tree :\n(Total no of my tokens encoded = "+str.size()+")\n-------------------------------\n";
       for(String tok : str)
           print = print + tok + "\t" + hash_table.get(tok) + "\n" ;
       
       final OutputStream outFile = new FileOutputStream(outputHuffmanTreeFile);
       final PrintStream printStream = new PrintStream(outFile);
       printStream.print(print);
       printStream.close();
  
        } catch (Exception e) {
          System.out.println(e);
          e.printStackTrace();
 }

   }
   
 
   /* this Method creates a text file containing binary
    * format of the original input file by the user. */
   public static void binaryOutEncoding(String inputTextFile, String outputBinaryFile) throws IOException {
	  
	 try( BufferedReader br = new BufferedReader(new FileReader(inputTextFile)) ) { 
		 
  	   String line;
  	   String s = "";
  	    while ((line = br.readLine()) != null) {
  	    	s = s + "\n";
  	        s = s + line;
  	    }
  	  s = s.substring(1);
  	
  	  File outFile = new File(outputBinaryFile);
      FileOutputStream compressedFile = new FileOutputStream(outFile);
         StringTokenizer tokens = new StringTokenizer(s, "[ =+';().*{}[],!@#$%^&/]", true);
	        
	        while(tokens.hasMoreTokens()){
	        	String token = tokens.nextToken().toString();
	        	compressedFile.write(hash_table.get(token).getBytes());
	        }
	     compressedFile.close(); 
         compressedFile.flush(); 

     } catch (FileNotFoundException e) {
         System.err.println("File not found.");
         e.printStackTrace();
     }

 }
   
   
   /* this Method decodes the encoded binary file
    * and returns the string containing the decoded tokens */
   public static String decode(String outputBinaryFile, node n) {
	
	   try( BufferedReader br = new BufferedReader(new FileReader(outputBinaryFile)) ) {
	  	   String line;
	  	   String s = "";
	  	    while ((line = br.readLine()) != null) {
	  	        s = s + line;
	  	    }
	  	    
	  	   String str = "";
	  	   String input = "";
	  	   char[] charArray = s.toCharArray();
	  	 for(int i=0; i<charArray.length; i++) {	 
	  		 str = str + charArray[i];
	  		for (Map.Entry<String, String> entry : hash_table.entrySet()) {
	  		 if(entry.getValue().equals(str)) {
	  			 input = input + entry.getKey();
	  			 str = "";
	  		 }
	  		}
	  	 }
	  	 
		return input;
	  	    
	   } catch (Exception e) {
	         System.out.println(e);
	         e.printStackTrace();
	         System.exit(0);
	         return "Exception Found" ;
	     }
	   
   }
 
   
   /* this Method creates the text file containing
    * the decoded file, to be compared with the 
    * original text file */
   public static void textOutDecodings(String s) {
	   
	   try {  
		   final OutputStream outFile = new FileOutputStream("Decoded File.txt");
	       final PrintStream printStream = new PrintStream(outFile);
	       printStream.print(s);
	       
	       printStream.close();
	   } catch (Exception e) {
		   System.out.println(e);
		   System.exit(0);
	   }
	   
   }

}



/** 'min_heap' Class starts from here :
 *  this class contains the Priority Queue
 *  implemented using min-Heap **/

class min_heap {

	ArrayList<node> heap = new ArrayList<node>();
    private static final int start = 1;
    
    public min_heap() {
    	node n = new node("",Integer.MIN_VALUE);
    	heap.add(n);
    }
 
    private int parent(int position) {
        return position / 2;
    }
 
    private int right_child(int position) {
        return (2 * position) + 1;
    }
    
    private int left_child(int position) {
        return (2 * position);
    }
 
    private boolean isLeaf(int position) {
        if (position > (heap.size()-1) / 2  &&  position <= heap.size()-1)
            return true;
        else
        return false;
    }
 
    private void swap(int position1, int position2) {
        node temp = heap.get(position1);
        heap.set(position1, heap.get(position2));
        heap.set(position2, temp);
    }
 
    private void heapify(int position) {
    	
        if (!isLeaf(position)) {
        	
        	if( right_child(position) <= heap.size()-1 ) {
              if ( heap.get(position).getFreq() > heap.get(left_child(position)).getFreq()  || heap.get(position).getFreq() > heap.get(right_child(position)).getFreq() ) {
          
                if ( heap.get(left_child(position)).getFreq() < heap.get(right_child(position)).getFreq() ) {
                    swap(position, left_child(position));
                    heapify(left_child(position));
                }
                else {
                    swap(position, right_child(position));
                    heapify(right_child(position));
                }
                
            }
        }
        	else if( left_child(position) <= heap.size()-1 && right_child(position) > heap.size()-1 ) {
        		if ( heap.get(position).getFreq() > heap.get(left_child(position)).getFreq() ) {
        			swap(position, left_child(position));
                    heapify(left_child(position));
        		}
        	}
        	else{ }            
        }
        
    }
 
    public void insert(node element) {
    	heap.add(element);
        int current = heap.size()-1;
 
        while (heap.get(current).getFreq() < heap.get(parent(current)).getFreq() ) {
            swap(current,parent(current));
            current = parent(current);
        }	
    }
 
    public void minHeap() {
        for (int position = (heap.size()-1) /2 ; position >= 1 ; position--) {
            heapify(position);
        }
    }
 
    public node removeMin() {
    	if( heap.size() > start ) {
        node pop = heap.get(start);
        heap.set(start,heap.get(heap.size()-1));
        heap.remove(heap.size()-1);
        heapify(start);
        return pop;
    	}
    	else
    		return heap.get(start);
    }
    
    public int size() {
    	int len = heap.size();
    	return len;
    }
    
    public boolean isEmpty() {
    	if(heap.size()>1)
    		return false;
        else
    		return true;
    }
    
}


/** 'node' Class starts from here: 
 *  this class contains all the characteristics of a node in a tree
 *  it is mainly used here to build the Huffman Tree **/

class node {
	
   String data;
   int frequency;
   node leftChild;
   node rightChild;
  
   node(String data, int frequency) {
      this.data = data;
      this.frequency = frequency;
      this.leftChild = null;
      this.rightChild = null;
   }

   node(String data,int frequency ,node lt, node rt) {
      this.data = data;
      this.frequency = frequency;
      this.leftChild = lt;
      this.rightChild = rt;
   }
   
   public String getElement() {
      return data;
   }
   public void setElement(String data) {
	  this.data = data;   
   }

   public int getFreq() {
	   return frequency;
   }
   public void setFreq(int freq) {
	   this.frequency = freq;
   }
   
   public node getLeft() {
      return leftChild;
   }
   public void setLeft(node newNode) {
      this.leftChild = newNode;
   }

   public node getRight() {
      return rightChild;
   }
   public void setRight(node newNode) {
      this.rightChild = newNode;
   }
   
   public boolean isLeaf(node newNode) {
	   if(newNode.leftChild == null && newNode.rightChild == null)
		   return true;
	   else
		   return false;
   }

}